// Define the calculateFinalGrade function at the top
function calculateFinalGrade(event) {
    // If called without an event, find the table directly
    const table = event ? event.target.closest("table") : document.querySelector("table");
    if (!table) return;

    // Select all rows except the first row (header) and the final grade row
    const rows = table.querySelectorAll("tr:not(:first-child, #finalGradeRow)");

    let totalWeightedScore = 0;
    let totalWeight = 0;
    let validInput = false;

    // Iterate over the selected rows
    rows.forEach(row => {
        const gradeInput = row.querySelector(".gradeInput");
        const weightInput = row.querySelector(".weightInput");
        const lostOutput = row.querySelector(".lostOutput");

        if (!gradeInput || !weightInput || !lostOutput) return;

        let grade = parseFloat(gradeInput.value);
        let weight = parseFloat(weightInput.value);

        if (!isNaN(grade) && !isNaN(weight) && weight > 0) {
            totalWeightedScore += grade * weight;
            totalWeight += weight;
            validInput = true;

            let lostValue = ((grade - 100) / 100) * weight;
            lostOutput.innerText = `${lostValue > 0 ? "+" : ""}${lostValue.toFixed(2)}%`;
            lostOutput.style.color = lostValue > 0 ? "#6aa84f" : lostValue < 0 ? "#cc0000" : "black";
        } else {
            lostOutput.innerText = "—";
            lostOutput.style.color = "black";
        }
    });

    // Update the final grade cell
    const finalGradeCell = table.querySelector(".finalGrade");
    if (!finalGradeCell) return;

    if (!validInput) {
        finalGradeCell.innerText = "Pending";
        finalGradeCell.style.color = "black";
        return;
    }

    let finalGrade = totalWeight > 0 ? (totalWeightedScore / totalWeight) : 0;
    finalGradeCell.innerText = `${finalGrade.toFixed(2)}%`;
    finalGradeCell.style.color = finalGrade >= 80 ? "#6aa84f" : finalGrade >= 50 ? "#E65100" : "#cc0000";
}

document.addEventListener("DOMContentLoaded", function () {
    const table = document.querySelector("table");
    const addRowButton = document.getElementById("addRowButton");

    // Add Final Grade row to the table
    const finalGradeRow = document.createElement("tr");
    finalGradeRow.id = "finalGradeRow";
    finalGradeRow.innerHTML = `
        <td colspan="2" style="font-weight: bold; text-align: left; background-color: #FFF9C4; color: black; padding: 14px;">Current Mark:</td>
        <td colspan="4" class="finalGrade" style="font-weight: bold; text-align: left; background-color: #FFF9C4; color: black; padding: 14px;">0.00%</td>
    `;
    table.appendChild(finalGradeRow);

    function addRow(event) {
        const clickedButton = event.target;
        const currentRow = clickedButton.closest("tr");
        const table = currentRow.closest("table"); // Find the correct table
    
        newRow.innerHTML = `
            <td><input type="text"></td>
            <td><input type="text" class="dueInput"></td>
            <td><input type="number" class="gradeInput"></td>
            <td><input type="number" class="weightInput"></td>
            <td><span class="lostOutput">—</span></td>
            <td class="actionsColumn">
                <button class="addRowBtn" title="Add row below">+</button> 
                <button class="removeRowBtn" title="Remove selected row">-</button>
                <button class="moveRowBtn" title="Move selected row">&#9776;</button>
            </td>
        `;
    
        // Attach event listeners to new row
        newRow.querySelector(".addRowBtn").addEventListener("click", addRow);
        newRow.querySelector(".removeRowBtn").addEventListener("click", removeRow);
        newRow.querySelector(".gradeInput").addEventListener("input", calculateFinalGrade);
        newRow.querySelector(".weightInput").addEventListener("input", calculateFinalGrade);
    
        // Attach event listener for the moveRowBtn
        setupMoveRowButton(newRow.querySelector(".moveRowBtn"));
    
        // Insert the new row after the current row
        currentRow.insertAdjacentElement("afterend", newRow);
    
        // Update row colors
        updateRowColors();
    }

    function removeRow(event) {
        const rowToRemove = event.target.closest("tr");
        const totalRows = table.querySelectorAll("tr:not(:first-child, #finalGradeRow)").length;
        if (totalRows > 1) {
            rowToRemove.remove();
            updateRowColors();
            calculateFinalGrade(); // Recalculate when a row is removed
        } else {
            alert("At least one row must remain.");
        }
    }


    // Attach event listeners for existing rows
    document.querySelectorAll(".addRowBtn").forEach(btn => btn.addEventListener("click", addRow));
    document.querySelectorAll(".removeRowBtn").forEach(btn => btn.addEventListener("click", removeRow));
    document.querySelectorAll(".gradeInput, .weightInput").forEach(input => input.addEventListener("focusout", calculateFinalGrade));

    updateRowColors();
});

document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ DOM fully loaded. Checking for collapse buttons...");

    document.querySelectorAll("#fullScreen").forEach(fullScreenButton => {
        if (fullScreenButton) {
            fullScreenButton.removeEventListener("click", toggleCollapse); // Prevent duplicate event listeners
            fullScreenButton.addEventListener("click", toggleCollapse);
            console.log("✅ Collapse button event attached:", fullScreenButton);
        } else {
            console.error("❌ Error: Collapse button (fullScreen) not found in DOM.");
        }
    });
});

// adding in a model when settings icon is clicked
var modal = document.getElementById("settingsModal");

// Get the button that opens the modal
var btn = document.getElementById("settingsIcon");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

// Step 1: Select the color picker element
const bgColorPicker = document.getElementById("userBgColour");

// Step 2: Select multiple elements, including table headers and course sections
const bgElementsToColor = document.querySelectorAll(
    ".titleBox, #courseCode, .columnTitles, td[colspan='6'], th"
);

// Step 3: Add an event listener to detect color changes
bgColorPicker.addEventListener("input", function () {
    let newColor = this.value;

    // Step 4: Loop through all selected elements and apply the color change
    bgElementsToColor.forEach(element => {
        element.style.setProperty("background-color", newColor, "important");
    });

    console.log("Updated Background Color to:", newColor); // Debugging
});


// Step 1: Select the color picker element
const fgColorPicker = document.getElementById("userFinalRowColour");

// Step 2: Select multiple elements (course section and all buttons)
const fgElementsToColor = document.querySelectorAll("#finalGrade, #finalGradeRow");

// Step 3: Add an event listener to detect color changes
bgColorPicker.addEventListener("input", function () {
    // Step 4: Loop through all selected elements and apply the color change
    fgElementsToColor.forEach(element => {
        element.style.backgroundColor = this.value;
    });
});

// NEED TO FIX FINALGRADEROW



// Step 1: Select the color picker element
const btnColorPicker = document.getElementById("userBtnColour");

// Step 2: Select multiple elements (course section and all buttons)
const btnElementsToColor = document.querySelectorAll("button");

// Step 3: Add an event listener to detect color changes
btnColorPicker.addEventListener("input", function () {

// Step 4: Apply the selected color as the background
btnElementsToColor.forEach(button => {
    button.style.backgroundColor = this.value;
});
});

// 1️⃣ Select the button that will trigger adding a new table
const addTableButton = document.getElementById("addTable");

// 2️⃣ Function to Toggle Collapse for a Given Table
function toggleCollapse(event) {
    const collapseButton = event.target;
    const table = collapseButton.closest(".table-wrapper")?.querySelector("table");

    if (!table) {
        console.error("❌ Table not found for collapse.");
        return;
    }

    table.classList.toggle("collapsed");

    // Ensure the final grade row remains visible
    const finalGradeRow = table.querySelector("#finalGradeRow");
    if (!finalGradeRow) {
        console.error("❌ Final Grade row not found.");
        return;
    }

    const finalMarkLabel = finalGradeRow.children[0]; // "Final Mark:" text cell
    const finalMarkValue = finalGradeRow.children[1]; // "0.00%" cell

    if (table.classList.contains("collapsed")) {
        finalMarkLabel.setAttribute("colspan", "1");
        finalMarkValue.setAttribute("colspan", "2");
        finalGradeRow.style.display = "table-row"; // Ensure visibility
        collapseButton.innerText = "⛶"; // Collapsed mode icon
        collapseButton.setAttribute("title", "Expand Table"); // Add hover text
    } else {
        finalMarkLabel.setAttribute("colspan", "3");
        finalMarkValue.setAttribute("colspan", "3");
        finalGradeRow.style.display = "table-row"; // Ensure visibility
        collapseButton.innerText = "←"; // Expanded mode icon
        collapseButton.setAttribute("title", "Collapse Table"); // Add hover text
    }
}

// 3️⃣ Function to Bind Collapse Event to All Tables
function bindCollapseEvent() {
    document.querySelectorAll(".table-wrapper").forEach((tableWrapper) => {
        const collapseButton = tableWrapper.querySelector("#fullScreen");

        if (collapseButton) {
            collapseButton.removeEventListener("click", toggleCollapse); // Prevent duplicates
            collapseButton.addEventListener("click", toggleCollapse);
            console.log("✅ Collapse button event attached to table:", tableWrapper);
        } else {
            console.warn("❌ Collapse button not found in:", tableWrapper);
        }
    });
}

// 4️⃣ Function to Add a Row
function addRow(event) {
    const clickedButton = event.target;
    const currentRow = clickedButton.closest("tr");
    const table = currentRow.closest("table"); // Find the correct table

    const newRow = document.createElement("tr");
    newRow.innerHTML = `
        <td><input type="text"></td>
        <td><input type="text" class="dueInput"></td>
        <td><input type="number" class="gradeInput"></td>
        <td><input type="number" class="weightInput"></td>
        <td><span class="lostOutput">—</span></td>
        <td class="actionsColumn">
            <button class="addRowBtn" title="Add row below">+</button> 
            <button class="removeRowBtn" title="Remove selected row">-</button>
            <button class="moveRowBtn" title="Move selected row">&#9776;</button>
        </td>
    `;

    // Attach event listeners to new row
    newRow.querySelector(".addRowBtn").addEventListener("click", addRow);
    newRow.querySelector(".removeRowBtn").addEventListener("click", removeRow);
    newRow.querySelector(".gradeInput").addEventListener("input", calculateFinalGrade);
    newRow.querySelector(".weightInput").addEventListener("input", calculateFinalGrade);

    // Attach event listener for the moveRowBtn
    setupMoveRowButton(newRow.querySelector(".moveRowBtn"));

    // Insert the new row after the current row
    currentRow.insertAdjacentElement("afterend", newRow);

    // Update row colors
    updateRowColors();
}

// 5️⃣ Function to Remove a Row
function removeRow(event) {
    const rowToRemove = event.target.closest("tr");
    const table = rowToRemove.closest("table");
    const totalRows = table.querySelectorAll("tr:not(:first-child, #finalGradeRow)").length;

    if (totalRows > 1) {
        rowToRemove.remove();
        console.log("✅ Removed row.");
    } else {
        alert("At least one row must remain.");
    }
}

// 6️⃣ Function to Bind Row Event Listeners to All Tables
function bindRowEvents() {
    document.querySelectorAll(".addRowBtn").forEach((btn) => {
        btn.removeEventListener("click", addRow); // Prevent duplicates
        btn.addEventListener("click", addRow);
    });

    document.querySelectorAll(".removeRowBtn").forEach((btn) => {
        btn.removeEventListener("click", removeRow); // Prevent duplicates
        btn.addEventListener("click", removeRow);
    });

    console.log("✅ Row event listeners bound to all tables.");
}

// Function to attach event listeners for the "Parse Syllabus" button and modal
function attachSyllabusButtonListeners(tableElement) {
    const syllabusModal = tableElement.querySelector("#syllabusModal");
    const syllabusButton = tableElement.querySelector("#syllabusButton");
    const closeModal = tableElement.querySelector("#syllabusModal .close");
    const parseSyllabusButton = tableElement.querySelector("#parseSyllabusButton");
    const syllabusTextbox = tableElement.querySelector("#syllabusTextbox");

    if (syllabusButton && syllabusModal && closeModal && parseSyllabusButton && syllabusTextbox) {
        // Open the modal when the syllabus button is clicked
        syllabusButton.addEventListener("click", function () {
            syllabusModal.style.display = "block";
        });

        // Close the modal when the close button is clicked
        closeModal.addEventListener("click", function () {
            syllabusModal.style.display = "none";
        });

        // Close the modal when clicking outside the modal
        window.addEventListener("click", function (event) {
            if (event.target === syllabusModal) {
                syllabusModal.style.display = "none";
            }
        });

        // Parse the syllabus when the "Parse Syllabus" button is clicked
        parseSyllabusButton.addEventListener("click", function () {
            const syllabusText = syllabusTextbox.value;

            // Call a function to parse the syllabus and populate the table
            parseSyllabus(syllabusText);

            // Close the modal after parsing
            syllabusModal.style.display = "none";
        });
    } else {
        console.error("❌ Error: Could not find syllabus button or modal elements in the new table.");
    }
}

// Function to add a new table
document.getElementById("addTable").addEventListener("click", function () {
    // Select the last table wrapper to duplicate
    const lastTable = document.querySelector(".table-wrapper:last-of-type");

    // Create a completely new table (instead of copying the last one)
    const newTable = document.createElement("div");
    newTable.classList.add("table-wrapper");
    newTable.innerHTML = `
        <table>
            <tr>
                <td colspan="6" id="courseHeader"> <!-- Updated to dynamically adjust -->
                    <div class="courseContainer">
                        <div class="titleBox">
                            <input type="text" placeholder="Insert Course Code" id="courseCode">
                            <button id="fullScreen" title="Collapse Table">←</button>
                            <input type="text" placeholder="Insert Course Topic" id="courseTopic">
                            <button id="syllabusButton" title="Parse Syllabus">📄</button>
                                <div id="syllabusModal" class="modal">
                                    <div class="modal-content">
                                        <span class="close">&times;</span>
                                        <textarea id="syllabusTextbox" placeholder="Paste the course syllabus here..."></textarea>
                                        <button id="parseSyllabusButton">Parse Syllabus</button>  
                                    </div>
                                </div>
                        </div>
                    </div>
                </td>
            </tr>             
            <tr class="columnTitles">
                <th>Evaluation</th>
                <th class="collapse-hide">Due</th>
                <th>Mark</th>
                <th class="collapse-hide">Weight</th>
                <th class="collapse-hide">Lost</th>
                <th class="collapse-hide">Actions</th>
            </tr>            
            ${generateDefaultRows(3)}
            <tr id="finalGradeRow">
                <td colspan="2" style="font-weight: bold; text-align: left; background-color: #FFF9C4; color: black; padding: 14px;">Current Mark:</td>
                <td colspan="4" class="finalGrade" style="font-weight: bold; text-align: left; background-color: #FFF9C4; color: black; padding: 14px;">0.00%</td>
            </tr>
        </table>
    `;

    // Insert new table after the last table
    lastTable.insertAdjacentElement("afterend", newTable);

    // Move "Add Course" button to always be after the last table
    newTable.insertAdjacentElement("afterend", document.getElementById("addTable"));

    // Attach event listeners to the new table
    attachEventListeners(newTable);

    // Attach event listeners for the "Parse Syllabus" button and modal
    attachSyllabusButtonListeners(newTable);

    // Bind collapse event to the new table
    bindCollapseEvent();

    console.log("✅ New table added with 3 default rows.");
});

// Function to generate default rows
function generateDefaultRows(numRows) {
    let rows = "";
    for (let i = 0; i < numRows; i++) {
        rows += `
            <tr>
                <td><input type="text" placeholder="Evaluation ${i + 1}"></td>
                <td><input type="text" class="dueInput"></td>
                <td><input type="text" class="gradeInput"></td>
                <td><input type="text" class="weightInput"></td>
                <td><span class="lostOutput">—</span></td>
                <td class="actionsColumn">
                    <button class="addRowBtn" title="Add row below">+</button> 
                    <button class="removeRowBtn" title="Remove selected row">-</button>
                    <button class="moveRowBtn" title="Move selected row">&#9776;</button>
                </td>
            </tr>
        `;
    }
    return rows;
}


// 9️⃣ Directly Attach Collapse Event for the **Original Table** (Fix)
document.addEventListener("DOMContentLoaded", function () {
    console.log("✅ DOM fully loaded. Attaching collapse event to original table...");
    
    // Find the original table's collapse button
    const originalCollapseButton = document.querySelector(".table-wrapper #fullScreen");

    if (originalCollapseButton) {
        originalCollapseButton.removeEventListener("click", toggleCollapse); // Prevent duplicates
        originalCollapseButton.addEventListener("click", toggleCollapse);
        console.log("✅ Collapse button attached to original table.");
    } else {
        console.warn("⚠ Original collapse button not found. It might be missing in the HTML.");
    }

    bindCollapseEvent(); // ✅ Ensures collapse works on the first table too
    bindRowEvents(); // ✅ Ensures add/remove row works on the original table
});


function attachEventListeners(tableElement) {
    console.log("Attaching event listeners to table:", tableElement);

    tableElement.querySelectorAll(".gradeInput, .weightInput").forEach(input => {
        input.addEventListener("input", calculateFinalGrade);
        console.log("Added input event listener to:", input);
    });

    tableElement.querySelectorAll(".addRowBtn").forEach(btn => {
        btn.addEventListener("click", addRow);
        console.log("Added click event listener to addRowBtn:", btn);
    });

    tableElement.querySelectorAll(".removeRowBtn").forEach(btn => {
        btn.addEventListener("click", removeRow);
        console.log("Added click event listener to removeRowBtn:", btn);
    });
}

function toggleNav() {
    var sidenav = document.getElementById("mySidenav");
    var menuIcon = document.getElementById("menuIcon");

    if (sidenav.style.width === "250px") {
        sidenav.style.width = "0";
        menuIcon.innerHTML = "&#9776;"; // Change back to menu icon
        menuIcon.classList.remove("open"); // Remove the flip effect
    } else {
        sidenav.style.width = "250px";
        menuIcon.innerHTML = "&times;"; // Change to close icon
        menuIcon.classList.add("open"); // Apply the flip effect

    }
}

function addTable() {
    const lastTable = document.querySelector(".table-wrapper:last-of-type");

    const newTable = document.createElement("div");
    newTable.classList.add("table-wrapper");
    newTable.innerHTML = `
        <table>
            <!-- Table content here -->
        </table>
    `;

    lastTable.insertAdjacentElement("afterend", newTable);
    newTable.insertAdjacentElement("afterend", document.getElementById("addTable"));

    // Attach event listeners to the new table
    attachEventListeners(newTable);
}

function attachEventListeners(tableElement) {
    tableElement.querySelectorAll(".gradeInput, .weightInput").forEach(input => {
        input.addEventListener("input", calculateFinalGrade);
    });

    tableElement.querySelectorAll(".addRowBtn").forEach(btn => {
        btn.addEventListener("click", addRow);
    });

    tableElement.querySelectorAll(".removeRowBtn").forEach(btn => {
        btn.addEventListener("click", removeRow);
    });
}

let isDragging = false;
let draggedRow = null;

function setupMoveRowButton(button) {
    button.addEventListener("mousedown", function (event) {
        isDragging = true;
        draggedRow = event.target.closest("tr");
        draggedRow.classList.add("dragging"); // Add the dragging class
        event.preventDefault();
    });
}

function handleMouseMove(event) {
    if (!isDragging || !draggedRow) return;

    const table = draggedRow.closest("table");

    // Select all rows except the column titles, course header, and final grade row
    const rows = Array.from(table.querySelectorAll("tr:not(.columnTitles):not(#courseHeader):not(#finalGradeRow)"));

    console.log("Rows:", rows); // Debugging: Check which rows are included

    const draggedIndex = rows.indexOf(draggedRow);

    // Remove any existing target row highlights
    rows.forEach(row => row.classList.remove("target-row"));

    // Find the row to swap with
    let targetRow = null;

    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const rect = row.getBoundingClientRect();
        const middleY = rect.top + rect.height / 2;

        if (event.clientY < middleY && i < draggedIndex) {
            row.classList.add("target-row");
            targetRow = row;
            break;
        } else if (event.clientY > middleY && i > draggedIndex) {
            row.classList.add("target-row");
            targetRow = rows[i + 1] || null;
            break;
        }
    }

    // Handle the case where the mouse is below the last row
    if (!targetRow) {
        const lastRow = rows[rows.length - 1];
        if (lastRow) {
            const lastRowRect = lastRow.getBoundingClientRect();
            if (event.clientY > lastRowRect.bottom) {
                // Highlight the last row
                lastRow.classList.add("target-row");

                // Move the dragged row to the bottom (above the #finalGradeRow)
                const finalGradeRow = table.querySelector("#finalGradeRow");
                if (finalGradeRow) {
                    table.tBodies[0].insertBefore(draggedRow, finalGradeRow);
                } else {
                    table.tBodies[0].appendChild(draggedRow);
                }
                return; // Exit early since we've handled the bottom case
            }
        }
    }

    // Move the dragged row to the target position
    if (targetRow) {
        table.tBodies[0].insertBefore(draggedRow, targetRow);
    }
}








function handleMouseUp() {
    if (isDragging && draggedRow) {
        draggedRow.classList.remove("dragging"); // Remove the dragging class
        document.querySelectorAll(".target-row").forEach(row => row.classList.remove("target-row"));
    }
    isDragging = false;
    draggedRow = null;
}

document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".moveRowBtn").forEach(button => {
        setupMoveRowButton(button);
    });

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
});

// Get the modal and button elements
const syllabusModal = document.getElementById("syllabusModal");
const syllabusButton = document.getElementById("syllabusButton"); // Correct ID
const closeModal = document.querySelector("#syllabusModal .close");
const parseSyllabusButton = document.getElementById("parseSyllabusButton");
const syllabusTextbox = document.getElementById("syllabusTextbox");

// Open the modal when the syllabus button is clicked
syllabusButton.addEventListener("click", function () {
    syllabusModal.style.display = "block";
});

// Close the modal when the close button is clicked
closeModal.addEventListener("click", function () {
    syllabusModal.style.display = "none";
});

// Close the modal when clicking outside the modal
window.addEventListener("click", function (event) {
    if (event.target === syllabusModal) {
        syllabusModal.style.display = "none";
    }
});

// Parse the syllabus when the "Parse Syllabus" button is clicked
parseSyllabusButton.addEventListener("click", function () {
    const syllabusText = syllabusTextbox.value;
    const table = this.closest(".table-wrapper")?.querySelector("table"); // Get the correct table
    if (table) {
        parseSyllabus(syllabusText, table); // Pass the correct table
    }
    syllabusModal.style.display = "none";
});



// Function to parse the syllabus and populate the table
function parseSyllabus(text, table) {
    // Split the input text into lines
    const lines = text.split('\n').map(line => line.trim()).filter(line => line);

    // Extract course code and title
    let courseCode = "";
    let courseTitle = "";

    const saveLocalCopyIndex = lines.findIndex(line => line.includes("Save a Local Copy"));
    if (saveLocalCopyIndex !== -1) {
        // Course code is on the next line
        courseCode = lines[saveLocalCopyIndex + 1] || "";

        // Course title is two lines below the course code
        courseTitle = lines[saveLocalCopyIndex + 3] || "";
    }

    // Remove the header lines (first two lines)
    const dataLines = lines.slice(2);

    // Array to store parsed components
    const components = [];

    // Process each line to extract component name and weight
    dataLines.forEach(line => {
        // Use a regex to extract the component name and weight
        const match = line.match(/^(.*?)\s+(\d+%)/);
        if (match) {
            const componentName = match[1].trim();
            const weight = match[2].trim();
            components.push({ name: componentName, weight: parseFloat(weight) });
        }
    });

    // Reset the table structure
    table.innerHTML = `
        <tr>
            <td colspan="6" id="courseHeader">
                <div class="courseContainer">
                    <div class="titleBox">
                        <input type="text" placeholder="Insert Course Code" id="courseCode" value="${courseCode}">
                        <button id="fullScreen" title="Collapse Table">←</button>
                        <input type="text" placeholder="Insert Course Topic" id="courseTopic" value="${courseTitle}">
                        <button id="syllabusButton" title="Parse Syllabus">📄</button>
                        <div id="syllabusModal" class="modal">
                            <div class="modal-content">
                                <span class="close">&times;</span>
                                <textarea id="syllabusTextbox" placeholder="Paste the course syllabus here..."></textarea>
                                <button id="parseSyllabusButton">Parse Syllabus</button>  
                            </div>
                        </div>
                    </div>
                </div>
            </td>
        </tr>
        <tr class="columnTitles">
            <th>Evaluation</th>
            <th class="collapse-hide">Due</th>
            <th>Mark</th>
            <th class="collapse-hide">Weight</th>
            <th class="collapse-hide">Lost</th>
            <th class="collapse-hide">Actions</th>
        </tr>
        ${components.map(component => `
            <tr>
                <td><input type="text" value="${component.name}"></td>
                <td><input type="text" class="dueInput"></td>
                <td><input type="number" class="gradeInput"></td>
                <td><input type="number" class="weightInput" value="${component.weight}"></td>
                <td><span class="lostOutput">—</span></td>
                <td class="actionsColumn">
                    <button class="addRowBtn" title="Add row below">+</button> 
                    <button class="removeRowBtn" title="Remove selected row">-</button>
                    <button class="moveRowBtn" title="Move selected row">&#9776;</button>
                </td>
            </tr>
        `).join('')}
        <tr id="finalGradeRow">
            <td colspan="2" style="font-weight: bold; text-align: left; background-color: #FFF9C4; color: black; padding: 14px;">Current Mark:</td>
            <td colspan="4" class="finalGrade" style="font-weight: bold; text-align: left; background-color: #FFF9C4; color: black; padding: 14px;">0.00%</td>
        </tr>
    `;

    // Reattach event listeners to the new elements
    attachEventListeners(table);

    // Recalculate the final grade
    calculateFinalGrade();
}

